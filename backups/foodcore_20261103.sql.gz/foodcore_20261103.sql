-- MySQL dump 10.13  Distrib 8.4.9, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: foodcore
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asistencia`
--

DROP TABLE IF EXISTS `asistencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistencia` (
  `id_asistencia` int NOT NULL AUTO_INCREMENT,
  `id_empleado` int NOT NULL,
  `fecha` date NOT NULL,
  `hora_ingreso` time NOT NULL,
  `hora_salida` time DEFAULT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'ASISTIO',
  PRIMARY KEY (`id_asistencia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia`
--

LOCK TABLES `asistencia` WRITE;
/*!40000 ALTER TABLE `asistencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `asistencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caja`
--

DROP TABLE IF EXISTS `caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `caja` (
  `id_caja` int NOT NULL AUTO_INCREMENT,
  `id_usuario_apertura` int NOT NULL,
  `id_usuario_cierre` int DEFAULT NULL,
  `nombre_caja` varchar(50) NOT NULL DEFAULT 'Caja Principal 01',
  `monto_apertura` decimal(14,2) NOT NULL DEFAULT '0.00',
  `monto_cierre` decimal(14,2) DEFAULT NULL,
  `fecha_apertura` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_cierre` timestamp NULL DEFAULT NULL,
  `estado` varchar(15) NOT NULL DEFAULT 'ABIERTA',
  `diferencia` decimal(14,2) DEFAULT '0.00',
  PRIMARY KEY (`id_caja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caja`
--

LOCK TABLES `caja` WRITE;
/*!40000 ALTER TABLE `caja` DISABLE KEYS */;
/*!40000 ALTER TABLE `caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Cat Hamburguesas','Hamburguesas artesanales a la parrilla',1),(2,'Cat Alitas & Pollo','Alitas y piezas crocantes',1),(3,'Cat Bebidas','Gaseosas y refrescos naturales',1);
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `tipo_documento` varchar(20) DEFAULT 'DNI',
  `numero_documento` varchar(20) NOT NULL,
  `nombre_razon_social` varchar(150) NOT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comanda`
--

DROP TABLE IF EXISTS `comanda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comanda` (
  `id_comanda` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int NOT NULL,
  `numero_comanda` varchar(20) NOT NULL,
  `fecha_hora_envio` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` varchar(20) NOT NULL DEFAULT 'PENDIENTE',
  `tiempo_estimado_min` int DEFAULT '15',
  PRIMARY KEY (`id_comanda`),
  KEY `fk_comanda_ped` (`id_pedido`),
  CONSTRAINT `fk_comanda_ped` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comanda`
--

LOCK TABLES `comanda` WRITE;
/*!40000 ALTER TABLE `comanda` DISABLE KEYS */;
/*!40000 ALTER TABLE `comanda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comprobante_pago`
--

DROP TABLE IF EXISTS `comprobante_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comprobante_pago` (
  `id_comprobante` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `tipo_comprobante` varchar(20) NOT NULL DEFAULT 'TICKET',
  `serie` varchar(10) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `fecha_emision` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `total` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id_comprobante`),
  UNIQUE KEY `id_venta` (`id_venta`),
  CONSTRAINT `fk_comp_venta` FOREIGN KEY (`id_venta`) REFERENCES `venta` (`id_venta`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comprobante_pago`
--

LOCK TABLES `comprobante_pago` WRITE;
/*!40000 ALTER TABLE `comprobante_pago` DISABLE KEYS */;
/*!40000 ALTER TABLE `comprobante_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_pedido`
--

DROP TABLE IF EXISTS `detalle_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_pedido` (
  `id_detalle_pedido` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` int NOT NULL DEFAULT '1',
  `precio_unitario` decimal(14,2) NOT NULL,
  `subtotal` decimal(14,2) NOT NULL,
  `notas_preparacion` varchar(255) DEFAULT '',
  `estado_cocina` varchar(15) NOT NULL DEFAULT 'PENDIENTE',
  `enviado_en` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `iniciado_en` datetime DEFAULT NULL,
  `listo_en` datetime DEFAULT NULL,
  PRIMARY KEY (`id_detalle_pedido`),
  KEY `fk_detped_ped` (`id_pedido`),
  KEY `fk_detped_prod` (`id_producto`),
  CONSTRAINT `fk_detped_ped` FOREIGN KEY (`id_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE CASCADE,
  CONSTRAINT `fk_detped_prod` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_pedido`
--

LOCK TABLES `detalle_pedido` WRITE;
/*!40000 ALTER TABLE `detalle_pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_venta`
--

DROP TABLE IF EXISTS `detalle_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_venta` (
  `id_detalle_venta` int NOT NULL AUTO_INCREMENT,
  `id_venta` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` int NOT NULL,
  `precio_unitario` decimal(14,2) NOT NULL,
  `subtotal` decimal(14,2) NOT NULL,
  PRIMARY KEY (`id_detalle_venta`),
  KEY `fk_detven_venta` (`id_venta`),
  CONSTRAINT `fk_detven_venta` FOREIGN KEY (`id_venta`) REFERENCES `venta` (`id_venta`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_venta`
--

LOCK TABLES `detalle_venta` WRITE;
/*!40000 ALTER TABLE `detalle_venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `id_empleado` int NOT NULL AUTO_INCREMENT,
  `dni` varchar(15) NOT NULL,
  `nombres` varchar(80) NOT NULL,
  `apellidos` varchar(80) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `cargo` varchar(50) NOT NULL,
  `sueldo_base` decimal(10,2) NOT NULL DEFAULT '1025.00',
  `fecha_ingreso` date NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_empleado`),
  UNIQUE KEY `dni` (`dni`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,'70000001','Administrador','General','999000001','Administrador ERP',3500.00,'2026-01-01',1),(2,'70000002','Maria','Cajera','999000002','Cajera Principal',1500.00,'2026-01-01',1),(3,'70000003','Carlos','Mozo','999000003','Mozo de Salón',1200.00,'2026-01-01',1),(4,'70000004','Pedro','Cocinero','999000004','Jefe de Cocina',1800.00,'2026-01-01',1);
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','init','SQL','V1__init.sql',1367857806,'foodcore_migrator','2026-11-03 05:17:54',1042,1),(2,'2','seed roles permisos','SQL','V2__seed_roles_permisos.sql',1716831198,'foodcore_migrator','2026-11-03 05:17:54',12,1),(3,'3','seed admin','SQL','V3__seed_admin.sql',-1931772845,'foodcore_migrator','2026-11-03 05:17:54',9,1),(4,'4','seed terminales','SQL','V4__seed_terminales.sql',-565438627,'foodcore_migrator','2026-11-03 05:17:54',22,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumo`
--

DROP TABLE IF EXISTS `insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insumo` (
  `id_insumo` bigint NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `unidad_medida` varchar(20) NOT NULL,
  `stock_actual_disponible` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `stock_minimo` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `costo_unitario` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `costo_unitario_actual` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_insumo`),
  UNIQUE KEY `codigo` (`codigo`),
  CONSTRAINT `ck_insumo_stock` CHECK ((`stock_actual_disponible` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumo`
--

LOCK TABLES `insumo` WRITE;
/*!40000 ALTER TABLE `insumo` DISABLE KEYS */;
INSERT INTO `insumo` VALUES (1,'INS-001','Carne de Res 150g','UND',50.0000,10.0000,4.5000,4.5000,1,'2026-11-03 00:17:54','2026-11-03 00:17:54',NULL,NULL,0),(2,'INS-002','Pan Brioche','UND',50.0000,10.0000,1.2000,1.2000,1,'2026-11-03 00:17:54','2026-11-03 00:17:54',NULL,NULL,0),(3,'INS-003','Alitas de Pollo','UND',60.0000,12.0000,1.5000,1.5000,1,'2026-11-03 00:17:54','2026-11-03 00:17:54',NULL,NULL,0);
/*!40000 ALTER TABLE `insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_vendible`
--

DROP TABLE IF EXISTS `item_vendible`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_vendible` (
  `id_item` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `precio_carta` decimal(14,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_vendible`
--

LOCK TABLES `item_vendible` WRITE;
/*!40000 ALTER TABLE `item_vendible` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_vendible` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kardex_movimiento`
--

DROP TABLE IF EXISTS `kardex_movimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kardex_movimiento` (
  `id_kardex` bigint NOT NULL AUTO_INCREMENT,
  `id_insumo` bigint NOT NULL,
  `tipo_movimiento` varchar(20) NOT NULL,
  `cantidad` decimal(14,4) NOT NULL,
  `saldo_anterior` decimal(14,4) NOT NULL,
  `saldo_posterior` decimal(14,4) NOT NULL,
  `costo_unitario` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `referencia_tipo` varchar(30) DEFAULT NULL,
  `referencia_id` bigint DEFAULT NULL,
  `id_usuario` bigint NOT NULL DEFAULT '1',
  `observacion` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_kardex`),
  KEY `idx_kardex_insumo_fecha` (`id_insumo`,`created_at`),
  CONSTRAINT `fk_kardex_insumo` FOREIGN KEY (`id_insumo`) REFERENCES `insumo` (`id_insumo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kardex_movimiento`
--

LOCK TABLES `kardex_movimiento` WRITE;
/*!40000 ALTER TABLE `kardex_movimiento` DISABLE KEYS */;
/*!40000 ALTER TABLE `kardex_movimiento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesa`
--

DROP TABLE IF EXISTS `mesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mesa` (
  `id_mesa` bigint NOT NULL AUTO_INCREMENT,
  `numero` varchar(10) NOT NULL,
  `estado` varchar(15) NOT NULL DEFAULT 'LIBRE',
  `version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_mesa`),
  UNIQUE KEY `numero` (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesa`
--

LOCK TABLES `mesa` WRITE;
/*!40000 ALTER TABLE `mesa` DISABLE KEYS */;
INSERT INTO `mesa` VALUES (1,'01','LIBRE',0),(2,'02','LIBRE',0),(3,'03','LIBRE',0),(4,'04','LIBRE',0);
/*!40000 ALTER TABLE `mesa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimiento_caja`
--

DROP TABLE IF EXISTS `movimiento_caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimiento_caja` (
  `id_movimiento` int NOT NULL AUTO_INCREMENT,
  `id_caja` int NOT NULL,
  `id_usuario` int NOT NULL,
  `tipo_movimiento` varchar(20) NOT NULL,
  `medio_pago` varchar(15) DEFAULT 'EFECTIVO',
  `monto` decimal(14,2) NOT NULL,
  `concepto` varchar(200) NOT NULL,
  `fecha_hora` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_movimiento`),
  KEY `fk_movcaja_caja` (`id_caja`),
  CONSTRAINT `fk_movcaja_caja` FOREIGN KEY (`id_caja`) REFERENCES `caja` (`id_caja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimiento_caja`
--

LOCK TABLES `movimiento_caja` WRITE;
/*!40000 ALTER TABLE `movimiento_caja` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimiento_caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimiento_inventario`
--

DROP TABLE IF EXISTS `movimiento_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimiento_inventario` (
  `id_movimiento_inv` int NOT NULL AUTO_INCREMENT,
  `id_insumo` bigint NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `cantidad` decimal(14,4) NOT NULL,
  `fecha_hora` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `motivo` varchar(200) NOT NULL,
  `referencia_id` int DEFAULT NULL,
  PRIMARY KEY (`id_movimiento_inv`),
  KEY `fk_movinv_insumo` (`id_insumo`),
  CONSTRAINT `fk_movinv_insumo` FOREIGN KEY (`id_insumo`) REFERENCES `insumo` (`id_insumo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimiento_inventario`
--

LOCK TABLES `movimiento_inventario` WRITE;
/*!40000 ALTER TABLE `movimiento_inventario` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimiento_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbox_evento`
--

DROP TABLE IF EXISTS `outbox_evento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbox_evento` (
  `id_evento` bigint NOT NULL AUTO_INCREMENT,
  `event_id` char(36) DEFAULT NULL,
  `tipo_evento` varchar(40) NOT NULL,
  `payload_json` json NOT NULL,
  `estado` varchar(15) NOT NULL DEFAULT 'PENDIENTE',
  `intentos` int NOT NULL DEFAULT '0',
  `proximo_intento` datetime DEFAULT CURRENT_TIMESTAMP,
  `creado_en` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enviado_en` datetime DEFAULT NULL,
  PRIMARY KEY (`id_evento`),
  KEY `idx_outbox_pendiente` (`estado`,`proximo_intento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbox_evento`
--

LOCK TABLES `outbox_evento` WRITE;
/*!40000 ALTER TABLE `outbox_evento` DISABLE KEYS */;
/*!40000 ALTER TABLE `outbox_evento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedido` (
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `id_mesa` bigint DEFAULT NULL,
  `id_usuario` int NOT NULL,
  `id_cliente` int DEFAULT NULL,
  `numero_mesa` varchar(10) NOT NULL,
  `fecha_hora` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `estado` varchar(20) NOT NULL DEFAULT 'REGISTRADO',
  `total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `idempotency_key` char(36) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_pedido`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permiso`
--

DROP TABLE IF EXISTS `permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permiso` (
  `codigo_permiso` varchar(60) NOT NULL,
  `descripcion` varchar(160) NOT NULL,
  PRIMARY KEY (`codigo_permiso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permiso`
--

LOCK TABLES `permiso` WRITE;
/*!40000 ALTER TABLE `permiso` DISABLE KEYS */;
INSERT INTO `permiso` VALUES ('CAJA_APERTURA','Autoriza aperturar un turno de caja con fondo inicial'),('CAJA_CIERRE','Autoriza ejecutar el arqueo físico y cierre Z del turno'),('CAJA_MOVIMIENTO_MANUAL','Autoriza registrar ingresos o egresos manuales en caja'),('CONFIG_RED','Autoriza configurar terminales y parámetros de red LAN'),('INSUMO_GESTIONAR','Autoriza administrar el catálogo de insumos, recetas y ajustes de stock'),('KARDEX_CONSULTAR','Autoriza consultar el libro mayor inmutable de movimientos de Kárdex'),('KDS_OPERAR','Autoriza transicionar estados de preparación en la pantalla KDS'),('PEDIDO_ADICIONAR','Autoriza agregar ítems a pedidos abiertos o en preparación'),('PEDIDO_ADICIONAR_POST_ENTREGA','Autoriza reabrir un pedido entregado para adición extraordinaria'),('PEDIDO_CREAR','Autoriza abrir una mesa y crear nuevos pedidos'),('TICKET_REIMPRIMIR','Autoriza emitir una copia marcada como REIMPRESIÓN de un ticket'),('USUARIO_GESTIONAR','Autoriza administrar usuarios, roles y desbloqueos'),('VENTA_ANULAR','Autoriza la anulación auditada de una venta registrada'),('VENTA_COBRAR','Autoriza el cobro de comandas y ventas POS');
/*!40000 ALTER TABLE `permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `id_producto` int NOT NULL AUTO_INCREMENT,
  `id_categoria` int NOT NULL,
  `codigo` varchar(20) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `precio_venta` decimal(14,2) NOT NULL,
  `costo_estimado` decimal(14,2) NOT NULL DEFAULT '0.00',
  `stock_disponible` int NOT NULL DEFAULT '100',
  `disponible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_producto`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `fk_prod_cat` (`id_categoria`),
  CONSTRAINT `fk_prod_cat` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES (1,1,'HAM-01','Hamburguesa Clasica','Carne 150g, queso cheddar y papas',18.50,7.50,100,1),(2,2,'ALI-01','Alitas BBQ x6','6 alitas bañadas en salsa BBQ',22.00,9.00,100,1),(3,3,'BEB-01','Gaseosa Personal','Botella 500ml helada',5.00,2.00,100,1);
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receta`
--

DROP TABLE IF EXISTS `receta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receta` (
  `id_receta` int NOT NULL AUTO_INCREMENT,
  `id_producto` int NOT NULL,
  `id_insumo` bigint NOT NULL,
  `cantidad_necesaria` decimal(14,4) NOT NULL,
  PRIMARY KEY (`id_receta`),
  UNIQUE KEY `uq_prod_insumo` (`id_producto`,`id_insumo`),
  KEY `fk_rec_ins` (`id_insumo`),
  CONSTRAINT `fk_rec_ins` FOREIGN KEY (`id_insumo`) REFERENCES `insumo` (`id_insumo`) ON DELETE RESTRICT,
  CONSTRAINT `fk_rec_prod` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receta`
--

LOCK TABLES `receta` WRITE;
/*!40000 ALTER TABLE `receta` DISABLE KEYS */;
INSERT INTO `receta` VALUES (1,1,1,1.0000),(2,1,2,1.0000),(3,2,3,6.0000);
/*!40000 ALTER TABLE `receta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receta_insumo`
--

DROP TABLE IF EXISTS `receta_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receta_insumo` (
  `id_receta` int NOT NULL,
  `id_insumo` bigint NOT NULL,
  `cantidad_requerida` decimal(14,4) NOT NULL,
  PRIMARY KEY (`id_receta`,`id_insumo`),
  KEY `fk_ri_insumo` (`id_insumo`),
  CONSTRAINT `fk_ri_insumo` FOREIGN KEY (`id_insumo`) REFERENCES `insumo` (`id_insumo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receta_insumo`
--

LOCK TABLES `receta_insumo` WRITE;
/*!40000 ALTER TABLE `receta_insumo` DISABLE KEYS */;
/*!40000 ALTER TABLE `receta_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `codigo_rol` varchar(30) NOT NULL,
  `codigo` varchar(30) GENERATED ALWAYS AS (`codigo_rol`) VIRTUAL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(150) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `codigo_rol` (`codigo_rol`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` (`id_rol`, `codigo_rol`, `nombre`, `descripcion`, `estado`) VALUES (1,'ADMIN','Administrador','Control total del sistema ERP, seguridad, usuarios y red',1),(2,'CAJERO','Cajero','Operación de POS, apertura/cierre de turno y arqueo de caja',1),(3,'MOZO','Mozo','Apertura de mesas y toma de comandas en salón',1),(4,'COCINA','Cocinero','Operación de línea de cocina KDS y despacho de ítems',1),(5,'ALMACEN','Almacenero','Control de insumos, recetas y consulta de Kárdex',1);
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol_permiso`
--

DROP TABLE IF EXISTS `rol_permiso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol_permiso` (
  `codigo_rol` varchar(30) NOT NULL,
  `codigo_permiso` varchar(60) NOT NULL,
  PRIMARY KEY (`codigo_rol`,`codigo_permiso`),
  KEY `fk_rp_permiso` (`codigo_permiso`),
  CONSTRAINT `fk_rp_permiso` FOREIGN KEY (`codigo_permiso`) REFERENCES `permiso` (`codigo_permiso`),
  CONSTRAINT `fk_rp_rol` FOREIGN KEY (`codigo_rol`) REFERENCES `rol` (`codigo_rol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol_permiso`
--

LOCK TABLES `rol_permiso` WRITE;
/*!40000 ALTER TABLE `rol_permiso` DISABLE KEYS */;
INSERT INTO `rol_permiso` VALUES ('ADMIN','CAJA_APERTURA'),('CAJERO','CAJA_APERTURA'),('ADMIN','CAJA_CIERRE'),('CAJERO','CAJA_CIERRE'),('ADMIN','CAJA_MOVIMIENTO_MANUAL'),('CAJERO','CAJA_MOVIMIENTO_MANUAL'),('ADMIN','CONFIG_RED'),('ADMIN','INSUMO_GESTIONAR'),('ADMIN','KARDEX_CONSULTAR'),('ADMIN','KDS_OPERAR'),('COCINA','KDS_OPERAR'),('ADMIN','PEDIDO_ADICIONAR'),('CAJERO','PEDIDO_ADICIONAR'),('MOZO','PEDIDO_ADICIONAR'),('ADMIN','PEDIDO_ADICIONAR_POST_ENTREGA'),('ADMIN','PEDIDO_CREAR'),('CAJERO','PEDIDO_CREAR'),('MOZO','PEDIDO_CREAR'),('ADMIN','TICKET_REIMPRIMIR'),('CAJERO','TICKET_REIMPRIMIR'),('ADMIN','USUARIO_GESTIONAR'),('ADMIN','VENTA_ANULAR'),('CAJERO','VENTA_ANULAR'),('ADMIN','VENTA_COBRAR'),('CAJERO','VENTA_COBRAR');
/*!40000 ALTER TABLE `rol_permiso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terminal`
--

DROP TABLE IF EXISTS `terminal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `terminal` (
  `id_terminal` bigint NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) NOT NULL,
  `descripcion` varchar(120) NOT NULL,
  `secreto_hash` char(60) NOT NULL,
  `rol_terminal` varchar(20) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `ultima_ip` varchar(45) DEFAULT NULL,
  `ultimo_acceso` datetime DEFAULT NULL,
  `ultimo_heartbeat` datetime DEFAULT NULL,
  PRIMARY KEY (`id_terminal`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terminal`
--

LOCK TABLES `terminal` WRITE;
/*!40000 ALTER TABLE `terminal` DISABLE KEYS */;
INSERT INTO `terminal` VALUES (1,'KDS-01','Pantalla de Cocina Principal KDS-01','$2a$12$BP1ioj65sjAcxPiN9NdVDOir1YPntePUhaOXHItvGRl/8pQOdEXrS','KDS',1,NULL,NULL,NULL),(2,'POS-01','Terminal de Caja Principal POS-01','$2a$12$BP1ioj65sjAcxPiN9NdVDOir1YPntePUhaOXHItvGRl/8pQOdEXrS','POS',1,NULL,NULL,NULL),(3,'KDS-INACTIVA','Terminal KDS Inactiva de Prueba','$2a$12$BP1ioj65sjAcxPiN9NdVDOir1YPntePUhaOXHItvGRl/8pQOdEXrS','KDS',0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `terminal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `turno_caja`
--

DROP TABLE IF EXISTS `turno_caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turno_caja` (
  `id_turno` bigint NOT NULL AUTO_INCREMENT,
  `id_usuario_apertura` bigint NOT NULL,
  `id_usuario_cierre` bigint DEFAULT NULL,
  `saldo_inicial` decimal(14,2) NOT NULL,
  `saldo_final_teorico` decimal(14,2) DEFAULT NULL,
  `saldo_final_contado` decimal(14,2) DEFAULT NULL,
  `diferencia` decimal(14,2) DEFAULT NULL,
  `estado` varchar(15) NOT NULL DEFAULT 'ABIERTO',
  `abierto_en` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cerrado_en` datetime DEFAULT NULL,
  `observacion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_turno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turno_caja`
--

LOCK TABLES `turno_caja` WRITE;
/*!40000 ALTER TABLE `turno_caja` DISABLE KEYS */;
/*!40000 ALTER TABLE `turno_caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `id_empleado` int NOT NULL DEFAULT '1',
  `id_rol` int NOT NULL DEFAULT '1',
  `username` varchar(50) NOT NULL,
  `nombre_usuario` varchar(50) DEFAULT NULL,
  `nombre_completo` varchar(120) NOT NULL DEFAULT 'Usuario FoodCore',
  `password_hash` varchar(255) NOT NULL,
  `hash_password` char(60) DEFAULT NULL,
  `codigo_rol` varchar(30) NOT NULL DEFAULT 'ADMIN',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `intentos_fallidos` int NOT NULL DEFAULT '0',
  `bloqueado_hasta` datetime DEFAULT NULL,
  `cambio_password_requerido` tinyint(1) NOT NULL DEFAULT '1',
  `ultimo_login` datetime DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `version` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,1,1,'admin','admin','Administrador General','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','ADMIN',1,0,NULL,1,NULL,'2026-11-03 05:17:54','2026-11-03 00:17:54','2026-11-03 00:17:54',0),(2,2,2,'cajero','cajero','Maria Cajera','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','CAJERO',1,0,NULL,0,NULL,'2026-11-03 05:17:54','2026-11-03 00:17:54','2026-11-03 00:17:54',0),(3,3,3,'mozo','mozo','Carlos Mozo','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','MOZO',1,0,NULL,0,NULL,'2026-11-03 05:17:54','2026-11-03 00:17:54','2026-11-03 00:17:54',0),(4,4,4,'cocinero','cocinero','Pedro Cocinero','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','$2a$12$eZvgEUon4XWZNbUonBboAuOUQkoM6bRz4f1EdyZbd8K/ZfhhguepK','COCINA',1,0,NULL,0,NULL,'2026-11-03 05:17:54','2026-11-03 00:17:54','2026-11-03 00:17:54',0);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `id_venta` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int DEFAULT NULL,
  `id_caja` int NOT NULL,
  `id_usuario` int NOT NULL,
  `id_cliente` int DEFAULT NULL,
  `fecha_hora` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `subtotal` decimal(14,2) NOT NULL,
  `igv` decimal(14,2) NOT NULL,
  `total` decimal(14,2) NOT NULL,
  `metodo_pago` varchar(20) NOT NULL DEFAULT 'EFECTIVO',
  `monto_recibido` decimal(14,2) NOT NULL DEFAULT '0.00',
  `vuelto` decimal(14,2) NOT NULL DEFAULT '0.00',
  `estado` varchar(15) NOT NULL DEFAULT 'COMPLETADA',
  `idempotency_key` char(36) DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  UNIQUE KEY `idempotency_key` (`idempotency_key`),
  KEY `fk_venta_caja` (`id_caja`),
  CONSTRAINT `fk_venta_caja` FOREIGN KEY (`id_caja`) REFERENCES `caja` (`id_caja`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'foodcore'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-03  0:21:31
